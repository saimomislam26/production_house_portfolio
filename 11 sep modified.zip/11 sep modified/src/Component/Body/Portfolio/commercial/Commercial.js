import React,{useState,useRef} from 'react'
import PortfolioNav from '../PortfolioNav'
import { IoCloseOutline } from "react-icons/io5";
import { BiLoaderAlt } from "react-icons/bi";
import { CommercialeData } from '../portfolioData'

const Commercial = () => {
    const [modal, setModal] = useState(false);
    const [videoLoading, setVideoLoading] = useState(true);
    const [link, setLink] = useState('');
    const allimagediv = useRef()
  
    const [spanText,setSpanText] = useState('')
    const [tooltipTag,setToolTipTag] =useState('')
  
    const openModal = () => {
      setModal(!modal);
    };
  
    const spinner = () => {
      setVideoLoading(!videoLoading);
    };
  
    // useEffect(()=> {
    //   Aos.init({duration: 2000,
    //     offset: 120,
      
    //   })
    // },[])
  
    const toolTipMove =(e,title,toolTipClass)=>{
      var x = e.clientX,
          y= e.clientY
      // console.log(title);
      setSpanText(title)
      setToolTipTag(toolTipClass)
      var finalTag = document.querySelector(`.${tooltipTag}`)
      
      if (spanText) {
        finalTag.style.top = (y+20) +'px';
        finalTag.style.left = (x+20) +'px';
      }
    }
  
    return (
      <div className='main-port' id='portpage' style={{
        backgroundColor: "#f8f8f8",
      }}>
        <div className='main-port-wrapper' id='port-wrapper'>
          <div><PortfolioNav /></div>
          <div className='portfolio-flex-container'>
            {
              CommercialeData.map((val, ind) => {
  
                return (
                  <>
                    <div className='thumbnail-div box'  id='thumbDiv' ref={allimagediv} key={val} onClick={() => {
                      setLink(val.link)
                      openModal()
                    }
  
                    }>
                      {modal ? (
                        <section className="modal__bg">
                          <div className="modal__align">
                            <div className="modal__content" modal={modal}>
                              <IoCloseOutline
                                className="modal__close"
                                arial-label="Close modal"
                                onClick={setModal}
                              />
                              <div className="modal__video-align embed-responsive embed-responsive-16by9">
                                {videoLoading ? (
                                  <div className="modal__spinner">
                                    <BiLoaderAlt
                                      className="modal__spinner-style"
                                      fadein="none"
                                    />
                                  </div>
                                ) : null}
                                <iframe
              
                                  className="modal__video-style"
                                  onLoad={spinner}
                                  loading="lazy"
                                  width="800"
                                  height="500"
                                  // "https://www.youtube.com/embed/4UZrsTqkcW4"
                                  src={link}
                                  // {val.link}
                                  title={val.title}
                                  frameBorder="0"
                                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                  allowFullScreen
                                ></iframe>
                              </div>
                            </div>
                          </div>
                        </section>
                      ) : null}
                      <div data-aos="fade-right">
  
                      <img src={val.img} onMouseMove={(e)=>toolTipMove(e,val.title,`tooltip${ind}`)} style={{ cursor: 'pointer', width: "100%" }}  className='img-fluid'  />
                      
                      
                      <span id='tooltip' className={`tooltip${ind}`}>{spanText}</span>
                      </div>
  
                    </div>
                  </>
                )
              })
            }
          </div>
        </div>
  
      </div>
    )
}

export default Commercial