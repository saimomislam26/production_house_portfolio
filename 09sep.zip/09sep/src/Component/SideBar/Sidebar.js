import React from 'react'
import { SidebarData } from './SidebarData'
import { useNavigate,useLocation } from 'react-router-dom'
const Sidebar = () => {
    const navigate = useNavigate()
    const location = useLocation()
    console.log(location);
    return (
        <div className='sidebar'>
            <div className='sidebar-name-top'><div>Jahan Iftekhar</div></div>
            
            <ul className='sidebar-list'>
            <div className='sidebar-name'><div>JAHAN</div></div>
                {
                    SidebarData.map((val, ind) => {
                        return (
                            <li
                                key={ind}
                                className="row"
                                onClick={() => navigate(val.link)}>
                                <div id="icon">{val.icon}</div>
                                <div id="title" className={location.pathname === val.link?"active":""} >{val.title}</div>
                            </li>
                        )
                    })
                }
            </ul>

        </div>
    )
}

export default Sidebar                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   