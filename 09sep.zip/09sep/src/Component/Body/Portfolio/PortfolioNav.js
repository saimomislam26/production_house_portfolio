import React from 'react'
import { useNavigate, useLocation } from 'react-router-dom'

const PortfolioNav = () => {
  const navigate = useNavigate()
  const location = useLocation()
  return (
    <div style={{

    }}><span className='portfolio-title'>Portfolio</span>
      <div className='navbar-flex-container row'>
        <div className='navbar-left col-12 col-lg-6'>
          <span className='navbar-title'>Creative Portfolio</span>
        </div>
        <div className='navbar-item col-12 col-lg-6 flex-wrap' id='port-nav-links'>
          <span className='Navbar-list' onClick={() => navigate('/portfolio')}>All</span>
          <span className='Navbar-list' onClick={() => navigate('/fashion')}>Fashion Film</span>
          <span className='Navbar-list' onClick={() => navigate('/documentary')}>Documentary</span>
          <span className='Navbar-list' onClick={() => navigate('/ovc')}>OVC</span>
          <span className='Navbar-list' onClick={() => navigate('/portfolio')}>Corporate</span>


        </div>

      </div></div>
  )
}

export default PortfolioNav