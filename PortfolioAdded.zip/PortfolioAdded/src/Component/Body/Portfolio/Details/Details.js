import React from 'react'
import PortfolioNav from '../PortfolioNav'
const Details = () => {
  return (
    <div className='main-port'>
        <PortfolioNav/>
    </div>
  )
}

export default Details