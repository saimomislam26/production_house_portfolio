import React, { useEffect, useState } from 'react'
import { FaFacebook, FaTwitter, FaYoutube, FaInstagram, FaTiktok } from 'react-icons/fa'
import profileimg from "../../assets/Picture2.png"
const Home = () => {
  const [style, setStyle] = useState(false);
  useEffect(()=> {
    setStyle(true)
  },[])

return (
  <div className='main'>
      <div className='main-container'>
        <div className={`container-wrapper ${style ? 'transformdiv': ''}`}>
          <div className='avatar'>
            <img src={profileimg} width="300px" alt='profile' />
          </div>
          <div className='details'>
            <h1>Jahan Iftekhar</h1>
            <p>Director Jahan Iftekhar is one of the most experienced and widely known Fashion Filmmakers in the
country. He has over 30 fashion films made under his planning and direction.</p>
            <ul className='social'>
              <li><a href="https://www.facebook.com"><FaFacebook /></a></li>
              <li><a href="https://www.facebook.com"><FaTwitter /></a></li>
              <li><a href="https://www.facebook.com"><FaYoutube /></a></li>
              <li><a href="https://www.facebook.com"><FaInstagram /></a></li>
              <li><a href="https://www.facebook.com"><FaTiktok /></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
)
}

export default Home