import logo1 from "../assets/img/logos/o-code.jpg"
import logo2 from "../assets/img/logos/pran.jpg"
import logo3 from "../assets/img/logos/sailor.jpg"
import logo4 from "../assets/img/logos/tagga-man.jpg"
import logo5 from "../assets/img/logos/twelve.jpg"
import logo6 from "../assets/img/logos/yellow.jpg"
import logo7 from "../assets/img/logos/zurham.jpg"


<div className="left">
<div className="about_title">
  <h3>Photography Skills</h3>
</div>
{/* END ABOUT TITLE */}

<div className="tokyo_progress">
  <div className="progress_inner" data-value="95">
    <span>
      <span className="label">Wedding Photography</span>
      <span className="number">95%</span>
    </span>
    <div className="background">
      <div className="bar">
        <div className="bar_in" style={{ width: 95 + '%' }}></div>
      </div>
    </div>
  </div>

  <div className="progress_inner" data-value="80">
    <span>
      <span className="label">Lifestyle Photography</span>
      <span className="number">80%</span>
    </span>
    <div className="background">
      <div className="bar">
        <div className="bar_in" style={{ width: 80 + '%' }}></div>
      </div>
    </div>
  </div>

  <div className="progress_inner" data-value="90">
    <span>
      <span className="label">Family Photography</span>
      <span className="number">90%</span>
    </span>
    <div className="background">
      <div className="bar">
        <div className="bar_in" style={{ width: 90 + '%' }}></div>
      </div>
    </div>
  </div>
</div>
{/* END PROGRESS */}
</div>

<Modal
        isOpen={isOpen}
        onRequestClose={toggleModal}
        contentLabel="My dialog"
        className="mymodal"
        overlayClassName="myoverlay"
        closeTimeoutMS={500}
      >
        <div className="tokyo_tm_modalbox_about">
          <button className="close-modal" onClick={toggleModal}>
            <img src="assets/img/svg/cancel.svg" alt="close icon" />
          </button>
          {/* END POPUP CLOSE BUTTON */}

          <div className="box-inner">
            <div className="description_wrap scrollable">
              {/* Read more content */}
              <p className='text-justify' style={{ fontStyle: 'italic', color: "#767676", lineHeight: '30px',marginTop:'10px' }}>
                While graduating in Media Studies and Journalism from the University of Liberal Arts (ULAB),
                he started his career in filmmaking by creating documentary films for NGO's.
                <span style={{
                  display: 'block',
                  marginTop: '1rem'
                }}></span>
                In his formative years, Jahan has worked many reputed directors and production houses. His
                journey started in 2012 as assistant director (Casting) of Amitabh Reza Chowdhury at Half
                Stop Down. Later on, working as an assistant director of Mezbaur Rahman Sumon in
                Facecard Production in 2013. And then as a post-production supervisor under the director
                Dhrubo Hassan at Outcaste Films in 2014
                <span style={{
                  display: 'block',
                  marginTop: '1rem'
                }}></span>
                He is the founder and director of A2Z Films, A full-fledged production company established
                in 2014. Under his strict supervision, A2Z Films has successfully developed many
                documentary films, online video commercials, Industrial and corporate videos, and fashion
                advertising campaigns.
                <span style={{
                  display: 'block',
                  marginTop: '1rem'
                }}></span>
                He aims to make full-length feature films shortly, to connect the audience through the art of
                his storytelling.

              </p>
              {/* Read More content */}
              <div className="my_box">
                
                {/* END LEFT */}

                <div className="right">
                  <div className="about_title">
                    <h3>Language Skills</h3>
                  </div>
                  {/* END TITLE */}
                  <div className="tokyo_progress">
                    <div className="progress_inner" data-value="95">
                      <span>
                        <span className="label">English</span>
                        <span className="number">95%</span>
                      </span>
                      <div className="background">
                        <div className="bar">
                          <div className="bar_in" style={{ width: 95 + '%' }}></div>
                        </div>
                      </div>
                    </div>

                    <div className="progress_inner" data-value="90">
                      <span>
                        <span className="label">Japanese</span>
                        <span className="number">90%</span>
                      </span>
                      <div className="background">
                        <div className="bar">
                          <div className="bar_in" style={{ width: 90 + '%' }}></div>
                        </div>
                      </div>
                    </div>

                    <div className="progress_inner" data-value="85">
                      <span>
                        <span className="label">Arabian</span>
                        <span className="number">85%</span>
                      </span>
                      <div className="background">
                        <div className="bar">
                          <div className="bar_in" style={{ width: 85 + '%' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* EDN TOKYO PROGRESS */}
                </div>
                {/* END RIGHT */}
              </div>
              {/* END MYBOX */}

              <div className="counter">
                <div className="about_title">
                  <h3>Fun Facts</h3>
                </div>
                <ul>
                  <li>
                    <div className="list_inner">
                      <h3>777+</h3>
                      <span>Projects Completed</span>
                    </div>
                  </li>
                  <li>
                    <div className="list_inner">
                      <h3>3K</h3>
                      <span>Happy Clients</span>
                    </div>
                  </li>
                  <li>
                    <div className="list_inner">
                      <h3>9K+</h3>
                      <span>Lines of Code</span>
                    </div>
                  </li>
                </ul>
                {/* END COUNTER CONTENT */}
              </div>
              {/* END COUNTER */}

              <div className="partners">
                <div className="about_title">
                  <h3>Our Partners</h3>
                </div>
                <Brand />
              </div>
              {/* END PARTNER SLIDER */}
            </div>
          </div>
        </div>
      </Modal>