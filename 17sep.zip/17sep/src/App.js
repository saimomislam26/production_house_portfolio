import React from "react"
import Routes from "./router/Routes"
import './style.css'
import 'bootstrap/dist/css/bootstrap.min.css';

const App = () => {

  return (
    <div className="tokyo_tm_all_wrap">  
      <Routes/>
    </div>
   
  );
}

export default App;

