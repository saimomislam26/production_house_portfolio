import codewinter from './images/codewinter.jpg'
import tagaman from './images/tagaman.jpg'
import sailor from './images/sailor.jpg'
import twelvecloth from './images/twelvecloth.jpg'
import zurhem from './images/zurhem.jpg'
import eppilyon from './images/Epyllion.jpg'
import tags from './images/Tags.jpg'
import shonglap from './images/Shonglap.jpg'
import kumarika from './images/kumarika.jpg'
import ocode from './images/ocode.jpg'
import oppo from './images/oppo.jpg'
import pranup from'./images/pranup.jpg'
import pranupval from './images/pranupvalantine.jpg'
import sailorgang from './images/sailorgang.jpg'
import sailoreid from './images/Sailoreid.jpg'
import sailoreshe from './images/sailorshe.jpg'
import sundrop from './images/sundrop.jpg'
import tagaman2 from './images/tagaman2.jpg'
import twelvewinter from './images/twelvewinter.jpg'
import yelowmen from './images/yellowmen.jpg'
import yelowwomen from './images/yellowwomen.jpg'
import Zurhem2 from './images/Zurhem2.jpg'

// "https://www.youtube.com/embed/4UZrsTqkcW4"
export const PortfolioData = [
    {
        title:"O | CODE Winter Collection",
        img: codewinter,
        link:"https://www.youtube.com/embed/bHAIQ_DUT2s"
    },
    {
        title:"TAAGA MAN Styling Studio",
        img: tagaman,
        link:"https://www.youtube.com/embed/csB88elEQ-4"
    },
    {
        title:"Sailor Winter 2020 ADV Campaign",
        img: sailor,
        link:"https://www.youtube.com/embed/xWmGVQGLQjI"
    },
    {
        title:"Twelve Clothing Winter 19-20 Campaign",
        img: twelvecloth,
        link:"https://www.youtube.com/embed/kDWtxKKKst0"
    },
    {
        title:"Zurhem FW 2017 fashion film",
        img: zurhem,
        link:"https://www.youtube.com/embed/lKohtZq14ws"
    },
    {
        title:"Silk Route Luxury Collection 2018 Campaign",
        img: eppilyon,
        link:"https://www.youtube.com/embed/yJ1_a4rh0kQ"
    },
    {
        title:"Sailor Eid 2018 Adv Campaign",
        img: sailoreid,
        link:"https://www.youtube.com/embed/V9KB_lb0N2Q"
    },
    {
        title:"22Tags.com Launch Commercial",
        img: tags,
        link:"https://www.youtube.com/embed/RBX2Sab-6zs"
    },
    {
        title:"Documentary “Shonglap for empowering girls”",
        img: shonglap,
        link:"https://www.youtube.com/embed/eAoiZK8RHpI"
    },
    {
        title:"Kumarika Miss Natural 2017",
        img: kumarika,
        link:"https://www.youtube.com/embed/2fDq7v_gQhQ"
    },
    {
        title:"O | CODE Presents Men’s Suit Campaign",
        img: ocode,
        link:"https://www.youtube.com/embed/t_yxqZiCc9g"
    },
    {
        title:"PRAN UP FEEELING at home",
        img: pranup,
        link:"https://www.youtube.com/embed/es_739_isbc"
    },

    // with title
    {
        title:"Pran Up Valentine",
        img: pranupval,
        link:"https://www.youtube.com/embed/ugebiWJohMI"
    },
    {
        title:"Get The Gang Back",
        img: sailorgang,
        link:"https://www.youtube.com/embed/l2WIOOgmKo0"
    },
    {
        title:"Sailor She is you Camp",
        img: sailoreshe,
        link:"https://www.youtube.com/embed/RNvYAbVdTnY"
    },
    {
        title:"Sundrop May Day",
        img: sundrop,
        link:"https://www.youtube.com/embed/ujxy6mg-QUo"
    },
    {
        title:"TAAGA MAN Eid ul Adha",
        img: tagaman2,
        link:"https://www.youtube.com/embed/VIq4EtWpwrM"
    },
    {
        title:"Twelve Winter 2020 Styling Campaign",
        img: twelvewinter,
        link:"https://www.youtube.com/embed/0lq0Z2uHj8o"
    },
    {
        title:"YELLOW Men's Eid Collection",
        img: yelowmen,
        link:"https://www.youtube.com/embed/6Kff0FrdipQ"
    },
    {
        title:"YELLOW Women's Eid Collection",
        img:yelowwomen ,
        link:"https://www.youtube.com/embed/kQZx63hcsS4"
    },
    {
        title:"Zurhem F/W 2019 Fashion Film",
        img: Zurhem2,
        link:"https://www.youtube.com/embed/4JXngQXmwrI"
    },
   
]